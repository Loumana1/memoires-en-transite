/*
 *  iemmatrix
 *
 *  objects for manipulating simple matrices
 *  mostly referring to matlab/octave matrix functions
 *
 * Copyright (c) IOhannes m zmölnig, forum::für::umläute
 * IEM, Graz, Austria
 *
 * For information on usage and redistribution, and for a DISCLAIMER OF ALL
 * WARRANTIES, see the file, "LICENSE.txt," in this distribution.
 *
 */
#include "iemmatrix.h"

static t_float binop(t_float f1, t_float f2)
{
#if PD_FLOATSIZE == 32
  return powf(f1, f2);
#else
  return pow(f1, f2);
#endif
}

void mtx_pow_setup(void)
{
  iemmatrix_binop_setup("mtx_.^", "mtx_pow", binop, (char *)0);
}

void iemtx_pow_setup(void) { mtx_pow_setup(); }
