---
title: mtx_logspace
description: create a logarithmically spaced matrix vector using start stop and numsteps
categories:
- object
pdcategory: Matrix Creation
see_also:
inlets:
  1st:
  - type: matrix
    description: ...
outlets:
  1st:
  - type: matrix
    description: ...
draft: true
---
